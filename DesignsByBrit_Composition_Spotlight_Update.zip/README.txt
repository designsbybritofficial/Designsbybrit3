Replace the main repository index.html with this file.

This changes the Design Spotlight to the composition poster. No hover, zoom, or extra effect was added.
